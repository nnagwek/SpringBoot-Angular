package com.springAngular.rest.webservices.springAngularrestwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAngularRestWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
